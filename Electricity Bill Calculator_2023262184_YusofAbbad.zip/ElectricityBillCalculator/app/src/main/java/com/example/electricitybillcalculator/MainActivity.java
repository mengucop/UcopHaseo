package com.example.electricitybillcalculator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        EditText unitsInput = findViewById(R.id.et_units);
        EditText rebateInput = findViewById(R.id.et_rebate);
        Button calculateButton = findViewById(R.id.btn_calculate);
        Button clearButton = findViewById(R.id.btn_clear);
        Button aboutButton = findViewById(R.id.btn_about);
        TextView tvUnitsUsed = findViewById(R.id.tv_units_used);
        TextView tvUnitsAmount = findViewById(R.id.tv_units_amount);
        TextView tvRebate = findViewById(R.id.tv_rebate);
        TextView tvRebateAmount = findViewById(R.id.tv_rebate_amount);
        TextView tvTotalBill = findViewById(R.id.tv_total_bill);
        TextView tvErrorMessage = findViewById(R.id.tv_error_message);

        calculateButton.setOnClickListener(v -> {
            try {
                String unitsStr = unitsInput.getText().toString();
                String rebateStr = rebateInput.getText().toString();

                if (unitsStr.isEmpty() || rebateStr.isEmpty()) {
                    tvErrorMessage.setText("Please fill in all fields.");
                    tvErrorMessage.setVisibility(View.VISIBLE);
                    return;
                }

                int units = Integer.parseInt(unitsStr);
                double rebate = Double.parseDouble(rebateStr);

                if (rebate < 0 || rebate > 5) {
                    tvErrorMessage.setText("Rebate percentage must be between 0 and 5.");
                    tvErrorMessage.setVisibility(View.VISIBLE);
                    return;
                }

                tvErrorMessage.setVisibility(View.GONE);

                double totalCharges = calculateBill(units);
                double rebateAmount = totalCharges * (rebate / 100);
                double totalBill = totalCharges - rebateAmount;

                tvUnitsUsed.setText(String.valueOf(units));
                tvUnitsAmount.setText(String.format("%.2f", totalCharges));
                tvRebate.setText(String.format("%.1f%%", rebate));
                tvRebateAmount.setText(String.format("%.2f", rebateAmount));
                tvTotalBill.setText(String.format("RM %.2f", totalBill));

            } catch (NumberFormatException e) {
                tvErrorMessage.setText("Invalid input. Please enter valid numbers.");
                tvErrorMessage.setVisibility(View.VISIBLE);
            }
        });

        clearButton.setOnClickListener(v -> {
            unitsInput.setText("");
            rebateInput.setText("");
            tvUnitsUsed.setText("");
            tvUnitsAmount.setText("");
            tvRebate.setText("");
            tvRebateAmount.setText("");
            tvTotalBill.setText("");
            tvErrorMessage.setVisibility(View.GONE);
        });

        aboutButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AboutActivity.class);
            startActivity(intent);
        });
    }

    private double calculateBill(int units) {
        double totalCharges = 0;
        int remainingUnits = units;

        // Bill calculation logic based on blocks
        int firstBlock = Math.min(remainingUnits, 200);
        totalCharges += firstBlock * 0.218;
        remainingUnits -= firstBlock;

        if (remainingUnits > 0) {
            int secondBlock = Math.min(remainingUnits, 100);
            totalCharges += secondBlock * 0.334;
            remainingUnits -= secondBlock;
        }

        if (remainingUnits > 0) {
            int thirdBlock = Math.min(remainingUnits, 300);
            totalCharges += thirdBlock * 0.516;
            remainingUnits -= thirdBlock;
        }

        if (remainingUnits > 0) {
            totalCharges += remainingUnits * 0.546;
        }

        return totalCharges;
    }
}
