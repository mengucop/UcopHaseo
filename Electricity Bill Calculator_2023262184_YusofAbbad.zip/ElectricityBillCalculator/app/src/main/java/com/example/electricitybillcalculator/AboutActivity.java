package com.example.electricitybillcalculator;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        // Initialize Views
        TextView tvAboutDetails = findViewById(R.id.tv_about_details);
        Button btnVisitGitHub = findViewById(R.id.btn_visit_github);
        Button btnBackToHome = findViewById(R.id.btn_back_to_home);

        // Set About Details with Improved Text
        String aboutDetails = "Developed by: YUSOF ABBAD BIN ABDUL AZIZ\n" +
                "Student ID: 2023262184\n" +
                "Program Code: CDCS2515B\n" +
                "Copyright © 2024";
        tvAboutDetails.setText(aboutDetails);

        // GitHub Button Action
        btnVisitGitHub.setOnClickListener(v -> {
            // Open GitHub Repository in Browser
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/mengucop/UcopHaseo"));
            startActivity(intent);

            // Show a Toast for user interaction
            Toast.makeText(AboutActivity.this, "Opening GitHub Repository...", Toast.LENGTH_SHORT).show();
        });

        // Back to Home Button Action
        btnBackToHome.setOnClickListener(v -> finish());
    }
}

