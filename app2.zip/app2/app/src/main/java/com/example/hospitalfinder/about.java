package com.example.hospitalfinder;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class about extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
    }

    // This method will be called when the GitHub TextView is clicked
    public void openGitHubLink(View view) {
        // Open the GitHub page using an implicit intent
        String url = "https://github.com/mengucop/UcopHaseo/tree/ICT602_Group";  // Replace with your actual GitHub URL
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
}
