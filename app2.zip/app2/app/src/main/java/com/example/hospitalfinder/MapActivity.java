package com.example.hospitalfinder;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.Vector;

public class MapActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private final LatLng CENTER_LOCATION = new LatLng(6.4433, 100.1940); // UiTM Arau
    private final Vector<MarkerOptions> markerOptions = new Vector<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        // Initialize Google Map
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // Add hospitals and clinics in Perlis
        addHospitalMarkers();
    }

    private void addHospitalMarkers() {
        markerOptions.add(new MarkerOptions().title("Hospital Tuanku Fauziah")
                .position(new LatLng(6.4305, 100.1912))
                .snippet("Open 24 Hours"));

        markerOptions.add(new MarkerOptions().title("Klinik Kesihatan Arau")
                .position(new LatLng(6.4356, 100.2642))
                .snippet("Open: 8AM - 5PM"));

        markerOptions.add(new MarkerOptions().title("Klinik Dr. Nizar Kangar")
                .position(new LatLng(6.4295, 100.1983))
                .snippet("Open: 9AM - 10PM"));

        markerOptions.add(new MarkerOptions().title("Klinik 1Malaysia Jejawi")
                .position(new LatLng(6.4715, 100.2043))
                .snippet("Open: 8AM - 5PM"));

        markerOptions.add(new MarkerOptions().title("Hospital Beseri")
                .position(new LatLng(6.5711, 100.2598))
                .snippet("Open: 24 Hours"));

        markerOptions.add(new MarkerOptions().title("Klinik Kesihatan Simpang Empat")
                .position(new LatLng(6.3794, 100.1696))
                .snippet("Open: 8AM - 5PM"));

        markerOptions.add(new MarkerOptions().title("Klinik Kesihatan Pauh")
                .position(new LatLng(6.5198, 100.2205))
                .snippet("Open: 8AM - 5PM"));

        markerOptions.add(new MarkerOptions().title("Klinik Perubatan Azhar")
                .position(new LatLng(6.4431, 100.2042))
                .snippet("Open: 9AM - 10PM"));

        markerOptions.add(new MarkerOptions().title("Klinik Kesihatan Kuala Perlis")
                .position(new LatLng(6.4050, 100.1254))
                .snippet("Open: 8AM - 5PM"));

        markerOptions.add(new MarkerOptions().title("Klinik Pakar Putra Kangar")
                .position(new LatLng(6.4409, 100.2013))
                .snippet("Open: 9AM - 6PM"));

        markerOptions.add(new MarkerOptions().title("Hospital Mata Kangar")
                .position(new LatLng(6.4300, 100.1950))
                .snippet("Open: 8AM - 5PM"));
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add markers to the map
        for (MarkerOptions mark : markerOptions) {
            mMap.addMarker(mark);
        }

        // Enable user's location if permission is granted
        enableMyLocation();

        // Move the camera to UiTM Arau with a zoom level of 12 (Perlis focus)
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(CENTER_LOCATION, 12));
    }

    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            if (mMap != null) {
                mMap.setMyLocationEnabled(true);
            }
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 200);
        }
    }
}
